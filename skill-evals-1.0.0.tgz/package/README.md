# Skill Eval Framework

## Overview

A medium-fidelity eval framework that tests Copilot CLI skills by:
1. Spinning up an isolated temp workspace with a scaffolded agent project
2. Running each eval prompt through the skill via the Copilot CLI
3. Judging the skill's output (tool calls, file changes, CLI commands, response) against expected behavior
4. Reporting results with per-eval pass/fail and overall scorecard

## Architecture

```
evals.json ──→ Runner ──→ Skill Output ──→ Judge ──→ Results
                 │                           │
                 ▼                           ▼
           Temp workspace            LLM-as-judge
           (scaffolded project)      (same model as CLI)
```

## Usage

```bash
# Run all evals for a skill
node run-evals.js --skill ~/.copilot/skills/m365-agent-developer

# Run specific eval by index
node run-evals.js --skill ~/.copilot/skills/m365-agent-developer --eval 5

# Run evals matching a pattern
node run-evals.js --skill ~/.copilot/skills/m365-agent-developer --filter "MCP"

# Output JSON results
node run-evals.js --skill ~/.copilot/skills/m365-agent-developer --output results.json
```

## Results

Results are saved to `results/` with timestamps. Each run produces:
- `results/<timestamp>.json` — Full structured results
- Console summary with pass/fail/partial counts and category breakdown
